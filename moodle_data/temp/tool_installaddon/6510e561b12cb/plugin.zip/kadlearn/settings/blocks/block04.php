<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Parent theme: boost
 *
 * @package   theme_kadlearn
 * @copyright 2022 ThemesAlmond  - http://themesalmond.com
 * @author    ThemesAlmond - Developer Team
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
// Block 4 info.
$name = 'theme_kadlearn/block04info';
$heading = get_string('block04info', 'theme_kadlearn');
$information = get_string('block04infodesc', 'theme_kadlearn');
$setting = new admin_setting_heading($name, $heading, $information);
$page->add($setting);
// Enable or disable block 4 settings.
$name = 'theme_kadlearn/block04enabled';
$title = get_string('block04enabled', 'theme_kadlearn');
$description = get_string('block04enableddesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 1);
$page->add($setting);
// Block 4 desing select.
$name = 'theme_kadlearn/block04desing';
$title = get_string('block04desing', 'theme_kadlearn');
$description = get_string('block04desingdesc', 'theme_kadlearn');
$default = 1;
$options = array();
for ($i = 1; $i < 3; $i++) {
     $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Block 4 header text.
$name = 'theme_kadlearn/block04header';
$title = get_string('block04header', 'theme_kadlearn');
$description = get_string('block04headerdesc', 'theme_kadlearn');
$default = get_string('block04headerdefault', 'theme_kadlearn');
$setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
$page->add($setting);
// Block 4 link button text and link.
$name = 'theme_kadlearn/block04button';
$title = get_string('block04button', 'theme_kadlearn');
$description = get_string('block04buttondesc', 'theme_kadlearn');
$default = get_string('block04buttondefault', 'theme_kadlearn');
$setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
$page->add($setting);

$name = 'theme_kadlearn/block04buttonlink';
$title = get_string('block04buttonlink', 'theme_kadlearn');
$description = get_string('block04buttonlinkdesc', 'theme_kadlearn');
$description = $description.get_string('underline', 'theme_kadlearn');
$default = get_string('block04buttonlinkdefault', 'theme_kadlearn');
$setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
$page->add($setting);

// Block 04 general settings END.
// ------------------------------------------------------------------------------------.
for ($i = 1; $i <= 8; $i++) {
     // Block 04 title.
     $name = 'theme_kadlearn/block04title'.$i;
     $title = get_string('block04title', 'theme_kadlearn', array('block' => $i));
     $description = get_string('block04titledesc', 'theme_kadlearn');
     $default = 'Latest '.$i;
     $setting = new admin_setting_configtext($name, $title, $description, $default);
     $page->add($setting);
     // Block 04 caption.
     $name = 'theme_kadlearn/block04caption'.$i;
     $title = get_string('block04caption', 'theme_kadlearn', array('block' => $i));
     $description = get_string('block04captiondesc', 'theme_kadlearn');
     $default = 'Latest caption'.$i;
     $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_RAW, '1', '2');
     $page->add($setting);
     // Block 04 img.
     $name = 'theme_kadlearn/sliderimageblock04img'.$i;
     $title = get_string('sliderimageblock04img', 'theme_kadlearn', array('block' => $i));
     $description = get_string('block04imgdesc', 'theme_kadlearn');
     $setting = new admin_setting_configstoredfile($name, $title, $description, 'sliderimageblock04img'.$i);
     $setting->set_updatedcallback('theme_reset_all_caches');
     $page->add($setting);
     // Block 04 link.
     $name = 'theme_kadlearn/block04link'.$i;
     $title = get_string('block04link', 'theme_kadlearn', array('block' => $i));
     $description = get_string('block04linkdesc', 'theme_kadlearn');
     $description = $description.get_string('underline', 'theme_kadlearn');
     $default = "https://moodle.org/";
     $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
     $page->add($setting);
}
