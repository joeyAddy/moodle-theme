// Theme info.
const idvar = document.getElementById("theme-info");
if (idvar) {
    document.getElementById("theme-info").innerHTML = "Moodle Theme kadlearn - Writer Themes Almond";
}
