/*
    Accordiontopic.js
    Copyright: 2022 ThemesAlmond
*/
var acc = document.getElementsByClassName("accordionkadlearn");
var i;
for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener('click', function() {
        this.classList.toggle('kadlearnactive');
        var panelkadlearn = this.nextElementSibling;
        if (panelkadlearn.style.display === 'block') {
            panelkadlearn.style.display = 'none';
        } else {
            panelkadlearn.style.display = 'block';
        }
    });
}
