<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Theme kadlearn page.
 *
 * @package   theme_kadlearn
 * @copyright 2022 ThemesAlmond  - http://themesalmond.com
 * @author    ThemesAlmond - Developer Team
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$page = new admin_settingpage('theme_kadlearn_kadlearnpage', get_string('kadlearnpage', 'theme_kadlearn'));
$page->add(new admin_setting_heading('theme_kadlearn_kadlearnpage', get_string('kadlearnpageheading', 'theme_kadlearn'),
format_text(get_string('kadlearnpageheadingdesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
// Enable or disable page settings.
$name = 'theme_kadlearn/kadlearnpageenabled';
$title = get_string('kadlearnpageenabled', 'theme_kadlearn');
$description = get_string('kadlearnpageenableddesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 1);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Count page settings.
$name = 'theme_kadlearn/kadlearnpagecount';
$title = get_string('kadlearnpagecount', 'theme_kadlearn');
$description = get_string('kadlearnpagecountdesc', 'theme_kadlearn');
$default = 1;
$options = array();
for ($i = 1; $i <= 10; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// If we don't have an slide yet, default to the preset.
$kadlearnpagecount = get_config('theme_kadlearn', 'kadlearnpagecount');
if (!$kadlearnpagecount) {
    $kadlearnpagecount = 2;
}
for ($count = 1; $count <= $kadlearnpagecount; $count++) {
    $name = 'theme_kadlearn/kadlearnpage' . $count . 'info';
    $heading = get_string('kadlearnpageno', 'theme_kadlearn', array('kadlearnpage' => $count));
    $information = get_string('kadlearnpagenodesc', 'theme_kadlearn', array('kadlearnpage' => $count));
    $setting = new admin_setting_heading($name, $heading, $information);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page title.
    $name = 'theme_kadlearn/kadlearnpagetitle' . $count;
    $title = get_string('kadlearnpagetitle', 'theme_kadlearn');
    $description = get_string('kadlearnpagetitledesc', 'theme_kadlearn');
    $setting = new admin_setting_configtext($name, $title, $description, '', PARAM_TEXT);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page caption.
    $name = 'theme_kadlearn/kadlearnpagecap' . $count;
    $title = get_string('kadlearnpagecaption', 'theme_kadlearn');
    $description = get_string('kadlearnpagecaptiondesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page css link.
    $name = 'theme_kadlearn/kadlearnpagecsslink' . $count;
    $title = get_string('kadlearnpagecsslink', 'theme_kadlearn');
    $description = get_string('kadlearnpagecsslinkdesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_RAW, '1', '1');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page img folder link.
    $name = 'theme_kadlearn/kadlearnpageimglink' . $count;
    $title = get_string('kadlearnpageimglink', 'theme_kadlearn');
    $description = get_string('kadlearnpageimglinkdesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_RAW, '1', '1');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page css.
    $name = 'theme_kadlearn/kadlearnpagecss' . $count;
    $title = get_string('kadlearnpagecss', 'theme_kadlearn');
    $description = get_string('kadlearnpagecssdesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_scsscode($name, $title, $description, $default, PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Add navbar to info page.
    $name = 'theme_kadlearn/kadlearnpagenavbar'. $count;
    $title = get_string('kadlearnpagenavbar', 'theme_kadlearn');
    $description = get_string('kadlearnpagenavbardesc', 'theme_kadlearn');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Add header to info page.
    $name = 'theme_kadlearn/kadlearnpageheader'. $count;
    $title = get_string('kadlearnpageheader', 'theme_kadlearn');
    $description = get_string('kadlearnpageheaderdesc', 'theme_kadlearn');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Add footer to info page.
    $name = 'theme_kadlearn/kadlearnpagefooter'. $count;
    $title = get_string('kadlearnpagefooter', 'theme_kadlearn');
    $description = get_string('kadlearnpagefooterdesc', 'theme_kadlearn');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
}
// Simple page.
$name = 'theme_kadlearn/kadlearnpageheadingsimple';
$heading = get_string('kadlearnpageheadingsimple', 'theme_kadlearn');
$information = get_string('kadlearnpageheadingsimpledesc', 'theme_kadlearn');
$setting = new admin_setting_heading($name, $heading, $information);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Enable or disable page settings.
$name = 'theme_kadlearn/kadlearnpageenabledsimple';
$title = get_string('kadlearnpageenabledsimple', 'theme_kadlearn');
$description = get_string('kadlearnpageenabledsimpledesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 1);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Count page settings.
$name = 'theme_kadlearn/kadlearnpagecountsimple';
$title = get_string('kadlearnpagecountsimple', 'theme_kadlearn');
$description = get_string('kadlearnpagecountsimpledesc', 'theme_kadlearn');
$default = 1;
$options = array();
for ($i = 1; $i <= 10; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// If we don't have an page yet, default to the preset.
$kadlearnpagecount = get_config('theme_kadlearn', 'kadlearnpagecountsimple');
if (!$kadlearnpagecount) {
    $kadlearnpagecount = 2;
}
for ($count = 1; $count <= $kadlearnpagecount; $count++) {
    $name = 'theme_kadlearn/kadlearnpagesimple' . $count . 'info';
    $heading = get_string('kadlearnpagenosimple', 'theme_kadlearn', array('kadlearnpage' => $count));
    $information = get_string('kadlearnpagenosimpledesc', 'theme_kadlearn', array('kadlearnpage' => $count));
    $setting = new admin_setting_heading($name, $heading, $information);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page title.
    $name = 'theme_kadlearn/kadlearnpagetitlesimple' . $count;
    $title = get_string('kadlearnpagetitlesimple', 'theme_kadlearn');
    $description = get_string('kadlearnpagetitlesimpledesc', 'theme_kadlearn');
    $setting = new admin_setting_configtext($name, $title, $description, '', PARAM_TEXT);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page image.
    $fileid = 'sliderimagekadlearnpagesimple'.$count;
    $name = 'theme_kadlearn/sliderimagekadlearnpagesimple'.$count;
    $title = get_string('kadlearnpageimagesimple', 'theme_kadlearn');
    $description = get_string('kadlearnpageimagesimpledesc', 'theme_kadlearn');
    $opts = array('accepted_types' => array('.png', '.jpg', '.gif', '.webp', '.tiff', '.svg'), 'maxfiles' => 1);
    $setting = new admin_setting_configstoredfile($name, $title, $description, $fileid,  0, $opts);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Count page settings.
    $name = 'theme_kadlearn/kadlearnpageimgpositionsimple'.$count;
    $title = get_string('kadlearnpageimgpositionsimple', 'theme_kadlearn');
    $description = get_string('kadlearnpageimgpositionsimpledesc', 'theme_kadlearn');
    $default = 1;
    $options = array(
        "1" => "Background",
        "2" => "Top",
        "21" => "Full Top",
        "3" => "Left",
        "4" => "Right"
    );
    $setting = new admin_setting_configselect($name, $title, $description, $default, $options);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Page caption.
    $name = 'theme_kadlearn/kadlearnpagecapsimple'.$count;
    $title = get_string('kadlearnpagecaptionsimple', 'theme_kadlearn');
    $description = get_string('kadlearnpagecaptionsimpledesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Add header to info page.
    $name = 'theme_kadlearn/kadlearnpageheadersimple'. $count;
    $title = get_string('kadlearnpageheadersimple', 'theme_kadlearn');
    $description = get_string('kadlearnpageheadersimpledesc', 'theme_kadlearn');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Add footer to info page.
    $name = 'theme_kadlearn/kadlearnpagefootersimple'. $count;
    $title = get_string('kadlearnpagefootersimple', 'theme_kadlearn');
    $description = get_string('kadlearnpagefootersimpledesc', 'theme_kadlearn');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
}
$page->add(new admin_setting_heading('theme_kadlearn_kadlearnpageend', get_string('kadlearnpageend', 'theme_kadlearn'),
format_text(get_string('kadlearnpageenddesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
$settings->add($page);
