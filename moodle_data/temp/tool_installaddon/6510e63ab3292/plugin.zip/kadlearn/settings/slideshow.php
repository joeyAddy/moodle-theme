<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Theme kadlearn slides.
 *
 * @package   theme_kadlearn
 * @copyright 2022 ThemesAlmond  - http://themesalmond.com
 * @author    ThemesAlmond - Developer Team
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$page = new admin_settingpage('theme_kadlearn_slide', get_string('slideshow', 'theme_kadlearn'));
$page->add(new admin_setting_heading('theme_kadlearn_slideshow', get_string('slideshowheading', 'theme_kadlearn'),
format_text(get_string('slideshowheadingdesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
// Slideshow desing select.
$name = 'theme_kadlearn/sliderdesing';
$title = get_string('sliderdesing', 'theme_kadlearn');
$description = get_string('sliderdesingdesc', 'theme_kadlearn');
$default = 1;
$options = array();
for ($i = 1; $i < 5; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

// Enable or disable Slideshow settings.
$name = 'theme_kadlearn/sliderenabled';
$title = get_string('sliderenabled', 'theme_kadlearn');
$description = get_string('sliderenableddesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 1);
$page->add($setting);

// Count Slideshow settings.
$name = 'theme_kadlearn/slidercount';
$title = get_string('slidercount', 'theme_kadlearn');
$description = get_string('slidercountdesc', 'theme_kadlearn');
$default = 4;
$options = array();
for ($i = 0; $i < 7; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// If we don't have an slide yet, default to the preset.
$slidercount = get_config('theme_kadlearn', 'slidercount');

if (!$slidercount) {
    $slidercount = 1;
}
// Header size setting.
$name = 'theme_kadlearn/slidershowheight';
$title = get_string('slidershowheight', 'theme_kadlearn');
$description = get_string('slidershowheight_desc', 'theme_kadlearn');
$default = '550';
$options = array(
        '250' => '250',
        '275' => '275',
        '300' => '300',
        '325' => '325',
        '350' => '350',
        '375' => '375',
        '400' => '400',
        '425' => '425',
        '450' => '450',
        '475' => '475',
        '500' => '500',
        '525' => '525',
        '550' => '550',
        '575' => '575',
        '600' => '600',
    );
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

// Frontpage color opacity to slider.
$name = 'theme_kadlearn/slideropacity';
$title = get_string('slideropacity', 'theme_kadlearn');
$description = get_string('slideropacitydesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 0);
$page->add($setting);

for ($count = 1; $count <= $slidercount; $count++) {
    $name = 'theme_kadlearn/slide' . $count . 'info';
    $heading = get_string('slideno', 'theme_kadlearn', array('slide' => $count));
    $information = get_string('slidenodesc', 'theme_kadlearn', array('slide' => $count));
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);
    // Slider image.
    $fileid = 'sliderimage'.$count;
    $name = 'theme_kadlearn/sliderimage'.$count;
    $title = get_string('sliderimage', 'theme_kadlearn');
    $description = get_string('sliderimagedesc', 'theme_kadlearn');
    $opts = array('accepted_types' => array('.png', '.jpg', '.gif', '.webp', '.tiff', '.svg'), 'maxfiles' => 1);
    $setting = new admin_setting_configstoredfile($name, $title, $description, $fileid,  0, $opts);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Slider title.
    $name = 'theme_kadlearn/slidertitle' . $count;
    $title = get_string('slidertitle', 'theme_kadlearn');
    $description = get_string('slidertitledesc', 'theme_kadlearn');
    $setting = new admin_setting_configtext($name, $title, $description, '', PARAM_TEXT);
    $page->add($setting);
    // Slider caption.
    $name = 'theme_kadlearn/slidercap' . $count;
    $title = get_string('slidercaption', 'theme_kadlearn');
    $description = get_string('slidercaptiondesc', 'theme_kadlearn');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $page->add($setting);
    // Slider button.
    $name = 'theme_kadlearn/sliderbutton' . $count;
    $title = get_string('sliderbutton', 'theme_kadlearn');
    $description = get_string('sliderbuttondesc', 'theme_kadlearn');
    $default = get_string('button', 'theme_kadlearn');
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
    $page->add($setting);
    // Slide button link.
    $name = 'theme_kadlearn/sliderurl'. $count;
    $title = get_string('sliderbuttonurl', 'theme_kadlearn');
    $description = get_string('sliderbuttonurldesc', 'theme_kadlearn');
    $default = 'http://www.example.com/';
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
    $page->add($setting);
}
$page->add(new admin_setting_heading('theme_kadlearn_slideend', get_string('slideshowend', 'theme_kadlearn'),
format_text(get_string('slideshowenddesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
$settings->add($page);
