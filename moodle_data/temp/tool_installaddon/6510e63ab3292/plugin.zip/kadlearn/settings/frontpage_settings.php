<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Theme kadlearn frontpage block setting.
 *
 * @package   theme_kadlearn
 * @copyright 2022 ThemesAlmond  - http://themesalmond.com
 * @author    ThemesAlmond - Developer Team
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$page = new admin_settingpage('theme_kadlearn_frontpage', get_string('frontpagekadlearn', 'theme_kadlearn'));
// Frontpage heading select.
$page->add(new admin_setting_heading('theme_kadlearn_frontpagenav', get_string('frontpagenav', 'theme_kadlearn'),
format_text(get_string('frontpagenavdesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
$name = 'theme_kadlearn/frontpagenavchoice';
$title = get_string('frontpagenavchoice', 'theme_kadlearn');
$description = get_string('frontpagenavchoicedesc', 'theme_kadlearn');
$default = 1;
$options = array();
for ($i = 1; $i < 4; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Add container to navigation bar.
$name = 'theme_kadlearn/navbarcontainer';
$title = get_string('navbarcontainer', 'theme_kadlearn');
$description = get_string('navbarcontainerdesc', 'theme_kadlearn');
$setting = new admin_setting_configcheckbox($name, $title, $description, 0);
$page->add($setting);
// Frontpage header logo select.
$name = 'theme_kadlearn/headerlogo';
$title = get_string('headerlogo', 'theme_kadlearn');
$description = get_string('headerlogodesc', 'theme_kadlearn');
$default = "Logo";
$options = array(
    'Logo' => 'Logo',
    'Compact logo' => 'Compact logo',
);
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Navbar back color.
$name = 'theme_kadlearn/navbarcolor';
$title = get_string('navbarcolor', 'theme_kadlearn');
$description = get_string('navbarcolor_desc', 'theme_kadlearn');
$setting = new admin_setting_configcolourpicker($name, $title, $description, '');
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);
// Menu light-dark.
$name = 'theme_kadlearn/frontpagenavlightdark';
$title = get_string('frontpagenavlightdark', 'theme_kadlearn');
$description = get_string('frontpagenavlightdarkdesc', 'theme_kadlearn');
$default = "navbar-light";
$options = array();
$options = array(
    'navbar-light' => 'navbar-light',
    'navbar-dark' => 'navbar-dark',
);
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

// Frontpage nav link area.
$name = 'theme_kadlearn/frontpagenavlink';
$title = get_string('frontpagenavlink', 'theme_kadlearn');
$description = get_string('frontpagenavlinkdesc', 'theme_kadlearn');
$default = get_string('frontpagenavlinkdefault', 'theme_kadlearn');
$setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_RAW, '1', '6');
$page->add($setting);
// Frontpage header 3 phone number.
$name = 'theme_kadlearn/header3phone';
$title = get_string('header3phone', 'theme_kadlearn');
$description = get_string('header3phonedesc', 'theme_kadlearn');
$default = "";
$setting = new admin_setting_configtext($name, $title, $description, '', PARAM_TEXT);
$page->add($setting);
// Frontpage choice.
$page->add(new admin_setting_heading('theme_kadlearn_frontpagehead', get_string('frontpageheading', 'theme_kadlearn'),
format_text(get_string('frontpagedesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));

// Frontpage desing select.
$name = 'theme_kadlearn/frontpagechoice';
$title = get_string('frontpagechoice', 'theme_kadlearn');
$description = get_string('frontpagechoicedesc', 'theme_kadlearn');
$default = 1;
$options = array();
$options = array();
for ($i = 1; $i <= 1; $i++) {
    $options[$i] = $i;
}
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

// Frontpage color select.
$name = 'theme_kadlearn/frontpagecolor';
$title = get_string('frontpagecolor', 'theme_kadlearn');
$description = get_string('frontpagecolordesc', 'theme_kadlearn');
$default = '#4272d7';
$options = array();
$options = array(
    '#4272d7' => '1',
    '#f98012' => '2',
    '#fa4251' => '3',
    '#c45e28' => '4',
    '#63c76a' => '5',
    '#024E64' => '6',
);
$setting = new admin_setting_configselect($name, $title, $description, $default, $options);
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

// Frontpage color palet.
$name = 'theme_kadlearn/sitecolor';
$title = get_string('sitecolor', 'theme_kadlearn');
$description = get_string('sitecolor_desc', 'theme_kadlearn');
$setting = new admin_setting_configcolourpicker($name, $title, $description, '');
$setting->set_updatedcallback('theme_reset_all_caches');
$page->add($setting);

$page->add(new admin_setting_heading('theme_kadlearn_frontpageend', get_string('frontpageend', 'theme_kadlearn'),
format_text(get_string('frontpageenddesc', 'theme_kadlearn'), FORMAT_MARKDOWN)));
$settings->add($page);
